import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-new-speech',
  templateUrl: './new-speech.component.html'
})
export class NewSpeechComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
